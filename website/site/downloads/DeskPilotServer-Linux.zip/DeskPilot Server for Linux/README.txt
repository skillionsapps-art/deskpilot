DeskPilot Server 1.0.0 for Linux (Ubuntu, Debian, Mint, Fedora, Arch...)
====================================================================

1. Unzip, open a terminal in this folder and run:   ./install.sh
   (or right-click install.sh > Run as a Program)
2. DeskPilot Server starts and opens its settings page - choose a password.
3. It's in your app menu afterwards, or run:  deskpilot-server

Background service without a desktop:  ./install.sh --headless
Mouse/keyboard control needs an X11 session (on Ubuntu choose "Ubuntu on Xorg" at login).
To remove: ~/.local/share/deskpilot-server/uninstall.sh
