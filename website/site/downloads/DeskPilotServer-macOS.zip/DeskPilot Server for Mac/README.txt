DeskPilot Server 1.0.0 for macOS 11+
==================================

1. Unzip, then right-click "Install DeskPilot Server.command" > Open > Open
   (first time only - macOS asks because the script is downloaded).
2. Follow the Terminal window. Python is installed from python.org if missing.
3. DeskPilot Server appears in the menu bar and in your Applications folder (~/Applications).
4. Choose a password on the settings page that opens.
5. System Settings > Privacy & Security > Accessibility: switch on DeskPilot Server
   (or "Python") so your phone can move the mouse and type.

To remove: run uninstall.command in ~/Library/Application Support/DeskPilot Server.
