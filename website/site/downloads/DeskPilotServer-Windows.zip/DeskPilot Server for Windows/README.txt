DeskPilot Server 1.0.0 for Windows 10/11
=====================================

1. Unzip this folder (right-click > Extract All).
2. Double-click "Install DeskPilot Server".
   If Windows shows "Windows protected your PC", click More info > Run anyway.
3. The settings page opens in your browser. Choose a password.
4. If Windows Firewall asks about "pythonw", tick Private networks and click Allow.
5. On your Android phone open DeskPilot - your PC appears automatically.

Python 3.12 is downloaded from python.org automatically if you don't have it.
Remove it any time from Settings > Apps > DeskPilot Server.
