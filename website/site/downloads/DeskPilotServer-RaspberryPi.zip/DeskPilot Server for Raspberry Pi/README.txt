DeskPilot Server 1.0.0 for Raspberry Pi (Pi 3/4/5, Raspberry Pi OS)
===============================================================

1. Copy this folder to the Pi (or download it there), then in a terminal:
       unzip DeskPilotServer-RaspberryPi.zip
       cd "DeskPilot Server for Raspberry Pi"
       ./install.sh --headless
2. Type a password when asked. The server now starts automatically at every boot.
3. On your Android phone open DeskPilot - the Pi appears automatically.

With a desktop attached you can also run ./install.sh (no --headless) for the tray app.
Mouse/keyboard control needs X11:  sudo raspi-config > Advanced Options > Wayland > X11.
To remove: ~/.local/share/deskpilot-server/uninstall.sh
